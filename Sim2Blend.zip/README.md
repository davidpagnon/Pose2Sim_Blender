[![Open Source? Yes!](https://badgen.net/badge/Open%20Source%20%3F/Yes%21/blue?icon=github)](https://github.com/Naereen/badges/)
[![License](https://img.shields.io/badge/license-MIT-blue)](https://opensource.org/license/mit)
<!-- [![DOI](https://zenodo.org/badge/634044634.svg)](https://zenodo.org/badge/latestdoi/634044634)\ -->


# Sim2Blend

**`Sim2Blend` is a Blender add-on for importing OpenSim data:** model, motion, markers, and forces.

[OpenSim](https://simtk.org/projects/opensim) is an open-source software for research in biomechanics. Among other things, it is used for accurate motion capture. \
[Blender](https://www.blender.org) is an open-source software used for 3D modeling, animation, and rendering. 

Feel free to try [Pose2Sim](https://github.com/perfanalytics/pose2sim), an open-source pipeline for obtaining research-grade OpenSim results from consumer-grade cameras.

> N.B.: Sim2Blend is inspired from [BlendOsim](https://github.com/JonathanCamargo/BlendOsim). Unlike BlendOsim, Sim2Blend does not require using Matlab as an intermediary (and expensive) software between two open-source ones.

<img src='Content/Demo.gif' title='Sim2Blend demonstration. An OpenSim model imported in Blender, along with its motion, markers, and force results.'  width="760">


## Contents
1. [Installation](#installation)
2. [Demonstration](#demonstration)
3. [How to cite and how to contribute](#how-to-cite-and-how-to-contribute)


## Installation

Installation is a little tricky, but the following steps should do it smoothly. If you encounter any issue, please [submit an issue](https://github.com/davidpagnon/Sim2Blend/issues).

#### Prerequisites

- Install [Blender](https://www.blender.org/download/) (haven't tried with versions other than 3.6)
- Install [OpenSim](https://simtk.org/projects/opensim) (haven't tried with versions other than 4.4)
- Install [Miniconda](https://docs.conda.io/en/latest/miniconda.html)
- Download [Sim2Blend.zip](https://github.com/davidpagnon/Sim2Blend/raw/main/Sim2Blend.zip)

All of the above are free and open-source.

#### Find your Blender Python version

Open Blender, press Shift+F4

```
import sys
sys.version
```

Write down your Python version, e.g. 3.10.12

#### Install Sim2Blend libraries

Open Miniconda, and copy-paste (with the right Python version):
```
conda create -n Sim2Blend python=3.10.12 -y 
conda activate Sim2Blend
conda install -c opensim-org opensim -y
pip uninstall numpy
pip install numpy bpy vtk
```

#### Install Sim2Blend add-on

You will need admin rights for the next steps:
- Rename `python` in `C:\Program Files\Blender Foundation\Blender 3.6\3.6\python` to `python_old`
- Copy-paste there your `Sim2Blend` environment folder (to find its location, type `conda env list` in Anaconda prompt). Rename to `python`
- Open `C:\Program Files\Blender Foundation\Blender 3.6\3.6\python\Lib\opensim\__init__.py` 
  - comment out the line `# from .moco import *`
  - line 4, add the path to your OpenSim bin folder: `os.add_dll_directory(r"C:/OpenSim 4.4/bin")`

#### Install Sim2Blend add-on in Blender

- Blender -> Edit -> Preferences -> Add-ons -> Install -> Choose Sim2Blend.py
- Check `Sim2Blend` to enable it
- Click on the tiny arrow on the upper-right corner of the 3D viewport to open it

![Where to find Sim2Blend add-on](Content/Show_Sim2Blend.png)








## Demonstration

After installing and enabling the add-on, a new tab will appear at your tools panel: **BlendOsim**. 

![Options added to the tools panel](doc/toolspanel.png)

With this tab you can import:

- **Markers file**: takes a csv file containing the xyz trajectories of the markers in the motion capture recorded in the experiment. This import option inserts mesh spheres, labels, and animates the trajectory location at every keyframe.

- **Forces file**: takes a csv file containing the force, moments and center of pressure for the forceplate data recorded in the experiment.This import option inserts mesh arrows with the tail located at the center of pressure, pointing and scaled in the direction of the force. The location and magnitude of the force is animated at every keyframe provided in the csv file.

- **Model file**: corresponds to the description of the biomechanics model in .osim format. Adding the model will add STL surfaces parented to empty objects that can be later used for animation. 

- **Motion file**: a csv file containing the location and rotation for every segment in the model at each animation keyframe to animate. This option constructs the trajectories for the loaded model file.

Try the files in the example folder!





## How to cite and how to contribute

### How to cite

If you use Sim2Blend, please cite [Pagnon and Camargo, 2023].

     @misc{Pagnon2023,
       author = {Pagnon, David and Camargo, Jonathan},
       title = {Sim2Blend - OpenSim results in Blender},
       year = {2023},
       <!-- doi= {10.5281/zenodo.7903963}, -->
       publisher = {GitHub},
       journal = {GitHub repository},
       howpublished = {\url{https://github.com/davidpagnon/Sim2Blend}},
     }


### How to contribute

I would happily welcome any proposal for new features, code improvement, and more!\
If you want to contribute to Sports2D, please follow [this guide](https://docs.github.com/en/get-started/quickstart/contributing-to-projects) on how to fork, modify and push code, and submit a pull request. I would appreciate it if you provided as much useful information as possible about how you modified the code, and a rationale for why you're making this pull request. Please also specify on which operating system, as well as which Python, Blender, OpenSim versions you have tested the code.

*Here is a to-do list. Feel free to complete it:*
- [x] Compute **segment angles**.





- Explanation on where to find add-on with screenshot
- Installing OpenSim (for mot files)
- Run when file selected

Pipeline:
- Add cameras, scene, film from cameras, import cameras, import videos
- Pose2Sim: Detection, Calibration/Sync/Identification, Triangulation/Filtering, Scaling/IK
- Import model, mot, markers

To do list: 












```




```

pip install opencv-python -> ok
pip install pandas -> DLL library issue when importing