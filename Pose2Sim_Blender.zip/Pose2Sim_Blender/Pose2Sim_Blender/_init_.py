#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys


__version__ = '0.6.0'
VERSION = __version__